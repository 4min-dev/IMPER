export const API = "https://dobrayaimperia.ru/api";
